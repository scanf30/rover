import roslib
import rospy
import numpy as np
import cv2
from sensor_msgs.msg import Image
from std_msgs.msg import Int8
from cv_bridge import CvBridge, CvBridgeError
from dynamic_reconfigure.server import Server
from fruit_follower.cfg import hsv_configConfig

def publisher():

	def callback(config, level):
   		h1 = config.h_min
		s1 = config.s_min
		v1 = config.v_min
		h2 = config.h_max
		s2 = config.s_max
		v2 = config.v_max

	imgPub = rospy.Publisher('fruitImg', Image, queue_size = 1)
	yPub = rospy.Publisher('yAxis', Int8, queue_size = 1)
	rospy.init_node('fruit_follower', anonymous = False)

	bridge = CvBridge()

	lg = [h1, s1, v1]
	ug = [h2, s2, v2]

	lower_green = np.array(lg)
	upper_green = np.array(ug)

	cap = cv2.VideoCapture(1)
	cap.set(3, 660)
	cap.set(4, 480)

	def nothing(x):
   		pass

	cv2.namedWindow('image')
	
	cv2.waitKey(1)

	msg = Int8()

	rate = rospy.Rate(60)

	while not rospy.is_shutdown():
		

		msg.data = 0		

		ret, frame = cap.read()
		blurred = cv2.GaussianBlur(frame, (11,11), 0)
		hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

		mask = cv2.inRange(hsv, lower_green, upper_green)
		mask = cv2.erode(mask, None, iterations = 2)
		mask = cv2.dilate(mask, None, iterations = 2)

		(_, cnts, _) = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

		cv2.drawContours(frame, cnts, -1, (0, 255, 0), 3)
		cv2.line(frame, (0, 160), (660, 160), (255, 0, 0), 3)
		cv2.line(frame, (0, 320), (660, 320), (255, 0, 0), 3)

		if len(cnts) > 0:
		
			c = max(cnts, key = cv2.contourArea)
			((x, y), radius) = cv2.minEnclosingCircle(c)
			
			if (radius > 15):
				cv2.circle(frame, (int(x), int(y)), int(radius), (0, 255, 255), 2)
				cv2.circle(frame, (int(x), int(y)), 5, (0, 0, 255), -1)

				if (y < 160):
					msg.data = 1
				elif (y > 360):
					msg.data = -1

		yPub.publish(msg)

		
		try:
			imgPub.publish(bridge.cv2_to_imgmsg(frame, "bgr8"))
		except CvBridgeError as e:
			print(e)

		rate.sleep()

	cap.release()
	cv2.destroyAllWindows()

if __name__ == '__main__':

	srv = Server(hsv_configConfig, callback)
	
	try:
		publisher()
	except rospy.ROSInterruptException:
		pass
			
		

